var fs = require('fs');
var srcdata = fs.readFileSync('tr_reveal_ngss.json');
var src = JSON.parse(srcdata);
//console.log(rawmapping_data)


var targdata = fs.readFileSync('tr_reveal_cpl_template.json');
var tar = JSON.parse(targdata);
//console.log(rawmapping_datatar+"............")


var mapdata = fs.readFileSync('tr_reveal_mapping.json');
var map = JSON.parse(mapdata);


var parent_source, parent_target;
var parent_source_tag, parent_target_tag;
var mirror_json, mirror_json_target;
var imagename;
var previousindex = {};

previousindex.len = 0;
previousindex.name = "";

var target_mirror;
var maplength = map.mapping_data.length;
var counter = 0;
var assignTarget;

parent_source = map.mapping_data[counter].source_parent_name;
parent_source_tag = parent_source.split(".");

if (counter < maplength) {
    get_s_data(src, tar, parent_source_tag, counter);
}

// returns the next index of the "currentbuffer" JSON ()
// currentbuffer - JSON returnBuffer
// sPtags - parent information
// mdata - Mapping Data json
// index - current mapping index
// if the currentbuffer length is more than one this should return the next level JSON till the cycle reaches the currentbuffer length
async function getnextIndex(currentbuffer, sPtags, mdata, index) {
    if (currentbuffer.length > 1) {
        let index = 0;
        let returnBuffer = {};
        returnBuffer.data = currentbuffer[index][sPtags];
        returnBuffer.remainglength = currentbuffer.length - 1;
        returnBuffer.currentIndex = index;

        return returnBuffer;
    }
}

//assigning the target data_type
// currentBuffer - current JSON returnBuffer
// mapdata - current mapping data
// counter - current mapping index
async function assignTargetData(currentBuffer, target, mapdata, counter) {



    if (mapdata[counter].iterative == "yes") {

        if (currentBuffer.length < target.length) {
            target.splice(currentBuffer.length);
        }


        console.log(currentBuffer, "           CurrentBuffer")
        console.log(target, "                  TargetBuffer")
        debugger;

        for (var j = 0; j < (currentBuffer.length); j++) {

            debugger;
            if (target[j]) {


                debugger;
                 if (mapdata[counter].data_type == "index"){

                   debugger;

                   for(var i=0; i<currentBuffer.length;i++){
                      console.log(currentBuffer[i][mapdata[counter].source_key_name],"           BU");
                      if(currentBuffer[i][mapdata[counter].source_key_name] == true){
                        target[j][mapdata[counter].target_key_name] = i;
                        return;
                      }
                   }
                   debugger;
                 }
                 else if (mapdata[counter].para_tag == "yes" && currentBuffer[j][mapdata[counter].source_key_name] !== "" && target[j][mapdata[counter].target_key_name]!==undefined) {
                    if(typeof(target)== "object" && target[j][mapdata[counter].target_key_name] == undefined){
                      target[j] = '<p class=\"quill-source-editor\">' + currentBuffer[j][mapdata[counter].source_key_name] + '</p>';
                    }
                    else {
                      target[j][mapdata[counter].target_key_name] = '<p class=\"quill-source-editor\">' + currentBuffer[j][mapdata[counter].source_key_name] + '</p>';

                    }
                } else {
                    if (mapdata[counter].data_type == "image" && currentBuffer[j][mapdata[counter].source_key_name] !== "" && target[j][mapdata[counter].target_key_name]!==undefined) {
                        imagename = currentBuffer[j][mapdata[counter].source_key_name];
                        let imgPath = imagename.split("/");
                        target[j][mapdata[counter].target_key_name] = map.assets_config.image_path + imgPath[imgPath.length - 1];
                    }
                    else if (mapdata[counter].difference_in_index == "-1" && target[j][mapdata[counter].target_key_name]!==undefined) {
                        target[j][mapdata[counter].target_key_name] = currentBuffer[j][mapdata[counter].source_key_name] - 1;
                      }
                      else if (mapdata[counter].data_type == "hide" && target[j][mapdata[counter].target_key_name]!==undefined) {
                        if(currentBuffer[j][mapdata[counter].source_key_name]==true)
                        {
                          target[j][mapdata[counter].target_key_name] = false ;
                        }
                        else {
                          target[j][mapdata[counter].target_key_name] = true ;
                        }

                        }
                    else { // changing the data when there is no information on image path and text node
                      debugger;
                      if(target[j][parent_target_tag[parent_target_tag.length-1]])
                      {
                        target[j][parent_target_tag[parent_target_tag.length-1]][mapdata[counter].target_key_name] = currentBuffer[j][mapdata[counter].source_key_name];
                      }
                      else {
                        target[j][mapdata[counter].target_key_name] = currentBuffer[j][mapdata[counter].source_key_name];
                      }

                    }
                }
            } else {
              //target[mapdata[counter].target_key_name] = currentBuffer[j][mapdata[counter].source_key_name];
                //mirror_json_target[map.mapping_data[i].target_key_name]=mirror_json[j][map.mapping_data[i].source_key_name]
            }
            console.log(target, "                  TargetBuffer Modified")
        }

    } else {
        if (mapdata[counter].para_tag == "yes" && currentBuffer[mapdata[counter].source_key_name] !== "") {
            target[mapdata[counter].target_key_name] = '<p class=\"quill-source-editor\">' + currentBuffer[mapdata[counter].source_key_name] + '</p>';
        } else {
            if (mapdata[counter].data_type == "image" && currentBuffer[mapdata[counter].source_key_name] !== "") {
                imagename = currentBuffer[mapdata[counter].source_key_name];
                let imgPath = imagename.split("/");
                target[mapdata[counter].target_key_name] = map.assets_config.image_path + imgPath[imgPath.length - 1];
            } else { // changing the data when there is no information on image path and text node
                target[mapdata[counter].target_key_name] = currentBuffer[mapdata[counter].source_key_name];
            }
        }
    }
    return true;
}

async function getparentLength(source_parent) {
    return source_parent.length;
};

async function get_s_data(src, tar, source_parent, counter) {

    if (counter == maplength) {
        console.log(tar);
        //debugger;
        fs.writeFileSync('tr_reveal_cpl.json', JSON.stringify(tar));
        process.exit();
    }

    let parentLen = await getparentLength(source_parent);

    parent_source = map.mapping_data[counter].source_parent_name;
    parent_source_tag = parent_source.split(".");

    parent_target = map.mapping_data[counter].target_parent_name;
    parent_target_tag = parent_target.split(".");

    target_mirror = {};
    mirror_json = {};
    previousindex = {};
    previousindex.len = 0;
    previousindex.name = "";

     console.log(counter,"                   Counter");
    // console.log(maplength,"               maplength");
    if (counter < maplength) {
        if (parent_source_tag.length >= 1) {
            for (k = 0; k < parent_source_tag.length; k++) {
                if (k == 0) {
                    mirror_json = src[parent_source_tag[k]];
                    if (parent_source_tag.length == 1) { // check the source parent length is equal to one index
                        if (map.mapping_data[counter].target_parent_name != "") {
                            if (parent_target_tag.length == 1) { // check the target parent length is equal to one index
                                target_mirror = tar[parent_target_tag[0]];
                                assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter);

                            } else { // check the target parent length is more than one index
                                console.log("One Source Parent Level and One or More Target Parent Level");
                                for (var i = 0; i < parent_target_tag.length; i++) { // check the target parent length is more than one index for get the sub level json node
                                    if (i == 0) { // form the target JSON to assign Target data
                                        target_mirror = tar[parent_target_tag[i]];
                                        if (i == parent_target_tag.length - 1) { // calling assignTarget function when the length of the target parent is one;
                                            assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter);

                                        }
                                    } else {
                                        target_mirror = target_mirror[parent_target_tag[i]];
                                        if (i == parent_target_tag.length - 1) { // check the length of the target parent and if reaches the maximum execute assign data
                                            assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter); // calling assignTarget function when the length of the target parent more than one;

                                        }
                                    }
                                }
                            }
                        } else {
                            assignTarget = await assignTargetData(mirror_json, tar, map.mapping_data, counter);

                        }
                    }

                } else {
                    if (mirror_json) { //check if the child is available in the existing mirror JSON (the parent_source_tag[k] referes the parent name from the array)
                        if (mirror_json) {

                            //debugger;
                            if (mirror_json[parent_source_tag[k]].length != undefined) {

                                if (k != (parent_source_tag.length - 1)) {
                                    //debugger;
                                    previousindex.len = mirror_json[parent_source_tag[k]].length;
                                    previousindex.name = parent_source_tag[k];
                                    previousindex.data = mirror_json[parent_source_tag[k]];
                                } else if (k == (parent_source_tag.length - 1)) {
                                    //debugger;
                                    //previousindex.len = 0;
                                    //previousindex.name = parent_source_tag[k];
                                    //previousindex.data = mirror_json[parent_source_tag[k]];
                                    mirror_json = mirror_json[parent_source_tag[k]];
                                }

                            } else {
                                //debugger;
                                mirror_json = mirror_json[parent_source_tag[k]];
                            }

                            if (previousindex.len > 0 && previousindex.name != parent_source_tag[k]) {
                                //debugger;
                                //mirror_json = mirror_json[parent_source_tag[k]];
                            } else if (previousindex.len > 0 && k == (parent_source_tag.length - 1)) { // cycle if the options is the last parent
                                //debugger;
                                mirror_json = mirror_json[parent_source_tag[k]]; //- commented today (may 23)
                            } else if (previousindex.len > 0 && k != (parent_source_tag.length - 1)) { // cycle if the cells is the last parent
                                //debugger;
                                mirror_json = mirror_json[parent_source_tag[k]][0];
                            }

                            if (k == parent_source_tag.length - 1) { // check if pranent level reaches the length (typically works for first level)
                              //debugger;
                                for (var i = 0; i < parent_target_tag.length; i++) { // check the target parent length is more than one index for get the sub level json node
                                    if (i == 0) { // form the target JSON to assign Target data

                                        if(parent_target_tag[i] != ""){
                                            target_mirror = tar[parent_target_tag[i]];
                                        }else{
                                          target_mirror = tar;
                                        }
                                        if (i == parent_target_tag.length - 1) { // calling assignTarget function when the length of the target parent is one;
                                            //debugger;

                                            if(previousindex.len>0){
                                              for (var e = 0; e < previousindex.len; e++) {
                                                  debugger;
                                                  //target_mirror = previousindex.targetdata[e][parent_target_tag[i]]; // i represents child loop - target parent length
                                                  if(map.mapping_data[counter].data_type == "index"){
                                                      if(target_mirror.length < previousindex.len){
                                                          target_mirror.splice(previousindex.len);
                                                      }
                                                  }
                                                  previousindex.targetdata = [];
                                                  previousindex.targetdata.push(target_mirror[e]);
                                                  assignTarget = await assignTargetData(previousindex.data[e][parent_source_tag[k]], previousindex.targetdata, map.mapping_data, counter); // calling assignTarget function when the length of the target parent more than one;
                                              }
                                            }else{
                                              assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter);
                                            }


                                        }
                                    } else {
                                      //debugger;
                                        if (target_mirror.length != undefined) {
                                            previousindex.targetdata = target_mirror;

                                            debugger;

                                            if(map.mapping_data[counter].target_key_name == parent_target_tag[i]){
                                              previousindex.targetdata = target_mirror;
                                              target_mirror = target_mirror;
                                            }else{
                                              target_mirror = target_mirror[0][parent_target_tag[i]];
                                            }


                                        } else {
                                            //debugger;
                                            previousindex.targetdata = target_mirror[parent_target_tag[i]];
                                            target_mirror = target_mirror[parent_target_tag[i]];
                                        }

                                        if (i == parent_target_tag.length - 1) { // check the length of the target parent and if reaches the maximum execute assign data
                                          //debugger;

                                          if(previousindex.len>0){

                                            for (var e = 0; e < previousindex.len; e++) {
                                                //debugger;
                                                target_mirror = previousindex.targetdata[e][parent_target_tag[i]]; // i represents child loop - target parent length

                                                assignTarget = await assignTargetData(previousindex.data[e][parent_source_tag[k]], target_mirror, map.mapping_data, counter); // calling assignTarget function when the length of the target parent more than one;
                                            }
                                          }else{
                                            //debugger;

                                            if(previousindex.targetdata.length>0)
                                            {
                                              // for(z=0;z<mirror_json.length;z++)
                                              // {

                                                target_mirror = previousindex.targetdata;
                                                if(mirror_json.length<target_mirror.length)
                                                {
                                                  target_mirror.splice(mirror_json.length);
                                                }

                                                //debugger;
                                                 // calling assignTarget function when the length of the target parent more than one;
                                              //}
                                              for(z=0;z<mirror_json.length;z++)
                                              {

                                              assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter);
                                            }
                                            }
                                            else {
                                              target_mirror = previousindex.targetdata;
                                              //debugger;
                                              assignTarget = await assignTargetData(mirror_json, target_mirror, map.mapping_data, counter); // calling assignTarget function when the length of the target parent more than one;
                                            }

                                          }

                                        }
                                    }
                                }

                            } else {}
                        } else {
                            mirror_json = mirror_json[parent_source_tag[k]];
                        }
                    }
                }
            }
        }

        if (counter == maplength) {
            console.log("ALL DONE");
            console.log(tar);
        } else if (counter < maplength) {
            counter++;
            get_s_data(src, tar, parent_source_tag, counter);
        }

    } else {
        console.log("done")
    }
}
